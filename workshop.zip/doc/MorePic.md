[*back to Doc-Text*](README.md)

#Simple Date and Time Functions (Jquery)

![Clock](img/clock.PNG?raw=true "Clock")


#Simple Polygon and Circle Tool on OpenStreetMap

![Map](img/map.PNG?raw=true "Map")


#Many Configuration Parameter Easy to Use

![Config](img/config.PNG?raw=true "Config")
